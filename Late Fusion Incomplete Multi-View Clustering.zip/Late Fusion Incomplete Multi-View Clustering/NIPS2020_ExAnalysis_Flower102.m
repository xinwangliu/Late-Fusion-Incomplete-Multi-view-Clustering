clear
clc
warning off;

path = 'D:\wangzong\';
dataName = 'flower17'; 
%%%flower17; flower102; caltech101_nTrain5_48
%% UCI_DIGIT; CCV; proteinFold
%% %% %% washington; wisconsin; texas; cornell; caltech101_nTrain25_48

epsionset = [0.05];
len = length(epsionset);
qnorm = 2;
numofalg = 7;
maxIter = 20;

res_acc_mean = zeros(maxIter,numofalg);
res_nmi_mean = zeros(maxIter,numofalg);
res_pur_mean = zeros(maxIter,numofalg);
res_adj_mean = zeros(maxIter,numofalg);
for iter =1 : maxIter
    res_acc_10 = zeros(len,numofalg);
    res_nmi_10 = zeros(len,numofalg);
    res_pur_10 = zeros(len,numofalg);
    res_adj_10 = zeros(len,numofalg);
    for ie = 1 : len
        load([path,'work2020\myNIPS2020Res\',dataName,'_missingRatio_',num2str(epsionset(ie)),...
            '_norm_',num2str(qnorm),'_clustering_iter_',num2str(iter),'.mat'],'res');
        res_acc_10(ie,1:6) =  res(1,1:6);
        res_nmi_10(ie,1:6) =  res(2,1:6);
        res_pur_10(ie,1:6) =  res(3,1:6);
        res_adj_10(ie,1:6) =  res(4,1:6);
        clear res
        load([path,'work2020\myNIPS2020Res\',dataName,'_missingRatio_',num2str(epsionset(ie)),...
            '_norm_',num2str(qnorm),'_clustering_new_iter_',num2str(iter),'.mat'],'res');
        res_acc_10(ie,7) =  res(1,9);
        res_nmi_10(ie,7) =  res(2,9);
        res_pur_10(ie,7) =  res(3,9);
        res_adj_10(ie,7) =  res(4,9);
        clear res   
    end
    res_acc_mean(iter,:) = mean(res_acc_10);
    res_nmi_mean(iter,:) = mean(res_nmi_10);
    res_pur_mean(iter,:) = mean(res_pur_10);
    res_adj_mean(iter,:) = mean(res_adj_10);
end
[H(1),P1(1)] = ttest(res_acc_mean(:,1),res_acc_mean(:,7));
[H(2),P1(2)] = ttest(res_acc_mean(:,2),res_acc_mean(:,7));
[H(3),P1(3)] = ttest(res_acc_mean(:,3),res_acc_mean(:,7));
[H(4),P1(4)] = ttest(res_acc_mean(:,4),res_acc_mean(:,7));
[H(4),P1(5)] = ttest(res_acc_mean(:,5),res_acc_mean(:,7));
[H(4),P1(6)] = ttest(res_acc_mean(:,6),res_acc_mean(:,7));
P1(7) = 1;
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[H(1),P2(1)] = ttest(res_nmi_mean(:,1),res_nmi_mean(:,7));
[H(2),P2(2)] = ttest(res_nmi_mean(:,2),res_nmi_mean(:,7));
[H(3),P2(3)] = ttest(res_nmi_mean(:,3),res_nmi_mean(:,7));
[H(4),P2(4)] = ttest(res_nmi_mean(:,4),res_nmi_mean(:,7));
[H(4),P2(5)] = ttest(res_nmi_mean(:,5),res_nmi_mean(:,7));
[H(4),P2(6)] = ttest(res_nmi_mean(:,6),res_nmi_mean(:,7));
P2(7) = 1;
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[H(1),P3(1)] = ttest(res_pur_mean(:,1),res_pur_mean(:,7));
[H(2),P3(2)] = ttest(res_pur_mean(:,2),res_pur_mean(:,7));
[H(3),P3(3)] = ttest(res_pur_mean(:,3),res_pur_mean(:,7));
[H(4),P3(4)] = ttest(res_pur_mean(:,4),res_pur_mean(:,7));
[H(4),P3(5)] = ttest(res_pur_mean(:,5),res_pur_mean(:,7));
[H(4),P3(6)] = ttest(res_pur_mean(:,6),res_pur_mean(:,7));
P3(7) = 1;
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[H(1),P4(1)] = ttest(res_adj_mean(:,1),res_adj_mean(:,7));
[H(2),P4(2)] = ttest(res_adj_mean(:,2),res_adj_mean(:,7));
[H(3),P4(3)] = ttest(res_adj_mean(:,3),res_adj_mean(:,7));
[H(4),P4(4)] = ttest(res_adj_mean(:,4),res_adj_mean(:,7));
[H(4),P4(5)] = ttest(res_adj_mean(:,5),res_adj_mean(:,7));
[H(4),P4(6)] = ttest(res_adj_mean(:,6),res_adj_mean(:,7));
P4(7) = 1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
res_acc_mean_std = [mean(res_acc_mean);std(res_acc_mean)]
res_nmi_mean_std = [mean(res_nmi_mean);std(res_nmi_mean)]
res_pur_mean_std = [mean(res_pur_mean);std(res_pur_mean)]
res_adj_mean_std = [mean(res_adj_mean);std(res_adj_mean)]