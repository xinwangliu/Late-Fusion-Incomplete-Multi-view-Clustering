# Late Fusion Incomplete Multi-View Clustering


Please cite our paper if you find that the code is useful to you :)

@article{Liu2019Latefusion,
  author={X. {Liu} and X. {Zhu} and M. {Li} and L. {Wang} and C. {Tang} and J. {Yin} and D. {Shen} and H. {Wang} and W. {Gao}},
  journal={IEEE Transactions on Pattern Analysis and Machine Intelligence}, 
  title={Late Fusion Incomplete Multi-View Clustering}, 
  year={2019},
  volume={41},
  number={10},
  pages={2410-2423},}
